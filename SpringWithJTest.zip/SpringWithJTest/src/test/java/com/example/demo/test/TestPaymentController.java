package com.example.demo.test;

import static org.hamcrest.CoreMatchers.is;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;



import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.demo.config.AppConfig;
import com.example.demo.controller.PaymentController;
import com.example.demo.model.Payment;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes=AppConfig.class)
public class TestPaymentController {
	
	private MockMvc mock;
	@Autowired
	private PaymentController controller;
	
	@Before
	public void setUp() {
		
		mock=MockMvcBuilders.standaloneSetup(controller).build();
	}
	
	@Test
	public void testGetAll() throws Exception{
		
		mock.perform(get("/payment/get/{id}",203).
		accept(MediaType.APPLICATION_JSON)).
		andExpect(status().isOk()).
		andExpect(jsonPath("$.paymentId", Matchers.is(203))).
		andExpect(jsonPath("$.description", Matchers.is("credicardpmt"))).
		andExpect(jsonPath("$.amount", Matchers.is(4200.00)));
	}
	
	
	public static String asJsonstring(final Object obj)
	{
		try {
			return new ObjectMapper().writeValueAsString(obj);
			
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
		}
	}
	
	@Test
	public void testInsert() throws Exception{
		
		Payment mockCourse = new Payment(204, "cabpayment",6500);
		String expected ="{paymentId:204,description:ebillpmt,amount:8200.00}";
		RequestBuilder requestBuilder= MockMvcRequestBuilders.post("/payment/add")
				.accept(MediaType.APPLICATION_JSON)
				.content(asJsonstring(mockCourse))
				.contentType(MediaType.APPLICATION_JSON);
		
		
		MvcResult result= mock.perform(requestBuilder).andReturn();
	}
	
	

}
