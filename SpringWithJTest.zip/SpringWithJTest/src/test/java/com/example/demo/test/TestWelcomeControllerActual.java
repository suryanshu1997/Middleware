package com.example.demo.test;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.demo.SpringWithJTestApplicationTests;
import com.example.demo.config.AppConfig;
import com.example.demo.controller.WelcomeController;
import com.example.demo.services.LoanEligibility;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes=AppConfig.class)

public class TestWelcomeControllerActual {
	
	
		private  MockMvc mock;
		@Autowired
		private WelcomeController controller;
		
		
		
		@Before
		public void setup() {
			
			
			this.mock= MockMvcBuilders.standaloneSetup(controller).build();
		}
		
		@Test
		public void testGetEligibility() throws Exception
		{
			
			mock.perform(get("/check/{yearlyIncome}/{employement}",300000.00,"govt"))
					.andExpect(content().string("700000.0"));
		}
		
		@Test
		public void testGetMessage() throws Exception
		{
			mock.perform(get("/greet")).andExpect(status().isOk()).andExpect(content().string("testing"));
		}
		
	}


