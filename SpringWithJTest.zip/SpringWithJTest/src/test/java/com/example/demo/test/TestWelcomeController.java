package com.example.demo.test;


import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.demo.config.AppConfig;
import com.example.demo.controller.WelcomeController;
import com.example.demo.services.LoanEligibility;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes=AppConfig.class)
public class TestWelcomeController {
		
	
	private  MockMvc mock;
	@InjectMocks
	private WelcomeController controller;
	
	@Mock
	private LoanEligibility service;
	
	@Before
	public void setup() {
		
		
		this.mock= MockMvcBuilders.standaloneSetup(controller).build();
	}
	
	@Test
	public void testGetEligibility() throws Exception
	{
		when(service.checkEligibility(300000.00, "govt")).thenReturn(500000.00);
		
		mock.perform(get("/check/{yearlyIncome}/{employement}",300000.00,"govt"))
				.andExpect(content().string("500000.0"));
	}
	
	@Test
	public void testGetMessage() throws Exception
	{
		mock.perform(get("/greet")).andExpect(status().isOk()).andExpect(content().string("testing"));
	}
	
}
