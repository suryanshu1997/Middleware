package com.example.demo.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Payment;

@Service
public class PaymentService {
	
	
	private HashMap<Long, Payment> pmtList;
	private ArrayList<Payment> list;
	
	public PaymentService() {
		
		super();
		this.pmtList=new HashMap<>();
		
		pmtList.put(203L, new Payment(203,"credicardpmt",4200.00));
		pmtList.put(204L, new Payment(204,"ebillpmt",8200.00));
		
		
	}
	
	
	public int addToList(Payment pmt) {
		
	 int a=0;
		if(this.pmtList.put(pmt.getPaymentId(), pmt)==null)
		{
			a=1;
		}
		return a;
		
			
	} 
	public Payment findById(long id) {
		return this.pmtList.get(id);
	}
	
	public List<Payment> findAll(){
			 
	ArrayList<Payment> list =new ArrayList<Payment>(this.pmtList.values());
	return list;
	}

}
