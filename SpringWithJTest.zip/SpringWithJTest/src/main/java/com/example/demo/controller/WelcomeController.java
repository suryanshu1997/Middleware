package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.services.LoanEligibility;

@RestController
public class WelcomeController {
	
	@Autowired
	private LoanEligibility service;
	
	
	@GetMapping("/greet")
	public String getMessage() {
		
		return "testing";
	}
	
	@GetMapping("check/{yearlyIncome}/{employement}")
	public double check(@PathVariable("yearlyIncome")double yearlyIncome, @PathVariable("employement")String employement)
	{	
	return this.service.checkEligibility(yearlyIncome, employement);
}
}
