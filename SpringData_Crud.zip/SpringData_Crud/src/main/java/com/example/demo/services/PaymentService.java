package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.example.demo.model.Payment;
import com.example.demo.repository.PaymentRepository;

@Service
public class PaymentService {
	
	@Autowired
	private CrudRepository<Payment, Long> repo;
	
	
	public Iterable<Payment> findAll(){
		
		return repo.findAll();
	}
	
	
	public List<Payment> searchByCustomerName(String name)
	{
		PaymentRepository paymentRepo=(PaymentRepository)repo;
		return paymentRepo.findByCustomerName(name);
	}
	
	public List<Payment> searchByNameAndAmount(String name,double amount){
		
		PaymentRepository paymentRepo=(PaymentRepository)repo;
		return paymentRepo.findByCustomerNameAndTxnAmount(name, amount);
	}
}
