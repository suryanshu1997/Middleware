package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="vdsi_payment")
public class Payment {
	
	@Id
	@GeneratedValue
	@Column(name="txn_id")
	private long txnId;
	@Column(name="customer_name")
	private String customerName;
	@Column(name="txn_amount")
	private double txnAmount;
}
