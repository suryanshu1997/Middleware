package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.demo.Employee;
@Configuration
public class AppConfig {

	
	@Bean
	public Employee employee()
	{
		Employee employee = new Employee();
		employee.setEmployeeName("Ramesh");
		employee.setEmployeeNumber(929);
		return employee;
	}
}
