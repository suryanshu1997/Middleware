package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.BookDetails;
import com.example.demo.service.BookDetailsService;

@RestController
public class BookDetailsController {
	
	
	@Autowired
	private BookDetailsService service;
	
	@PostMapping(value= "/addBook" , produces="application/json", consumes="application/json")
	//@Secured("ROLE_ADMIN")
	public BookDetails sendBookDetails(@RequestBody  BookDetails entity)
	{
		return this.service.addBook(entity);
	}
	
	@GetMapping(value="/showBook" )
	//@Secured("ROLE_ADMIN")
	public List<BookDetails> showAll(){
		return (List<BookDetails>) this.service.showBook();
	}
	
	@PostMapping(value= "/deleteBook" )
	//@Secured("ROLE_ADMIN")
	public void deleteBook(@RequestBody BookDetails entity)
	{
		//System.out.println("=====from controller=============="+key);
	   this.service.deleteBookById(entity);
	}

}
