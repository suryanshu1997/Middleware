package com.example.demo.service;

import java.awt.RenderingHints.Key;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.BookDetails;
import com.example.demo.repository.BookRepository;
import com.example.demo.repository.SubscriberRepository;

@Service
public class BookDetailsService {
	
	@Autowired
	private BookRepository bookRepo;
	
	
	
	public BookDetails addBook(BookDetails entity)
	{
		return bookRepo.save(entity);
	}
	public Iterable<BookDetails> showBook(){
		
		return bookRepo.findAll();
	}
	public void deleteBookById(BookDetails entity)
	{
		
		bookRepo.deleteById(entity.getBookId());
	}
	
	
	

}
