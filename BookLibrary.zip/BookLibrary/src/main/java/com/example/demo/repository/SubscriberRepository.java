package com.example.demo.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Subscriber;

public interface SubscriberRepository extends CrudRepository<Subscriber, Long> {

	
	
}
