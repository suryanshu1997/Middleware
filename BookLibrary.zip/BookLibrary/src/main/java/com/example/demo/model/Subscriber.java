package com.example.demo.model;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TemporalType;


import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Component
@Entity
@Table(name="SubscriberDetails")

public class Subscriber {
	@Id
	private long subId;
	private String subName;
	private String issueDate;
	private String returnDate;
	private long penalty;
//	@OneToOne(cascade = CascadeType.PERSIST)
//	 @JoinColumn(name = "book_id")
//	private BookDetails bookDetails;

}
