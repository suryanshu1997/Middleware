package com.example.demo.controllers;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.Month;
import java.time.Period;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.BookDetails;
import com.example.demo.model.Subscriber;
import com.example.demo.service.SubscriberDetailsService;

@RestController
public class SubscriberDetailsController {
	
	@Autowired
	private SubscriberDetailsService subservice;
	//@Secured("ROLE_USER")
	@GetMapping(value="/getSubscriber/{id}")
	 public Subscriber showSubscriber(@PathVariable("id") long id)
	{
	return this.subservice.showDetails(id).get();
	}
	
	@PostMapping(value= "/issueBook" , produces="application/json", consumes="application/json")
	//@Secured("ROLE_ADMIN")
	public Subscriber sendSubscriberDetails(@RequestBody  Subscriber entity)
	{
		String from_date=entity.getIssueDate();
		LocalDate f_date=LocalDate.parse(from_date);
		String to_date=entity.getReturnDate();
		LocalDate t_date=LocalDate.parse(to_date);
		
		 Period intervalPeriod = Period.between(f_date, t_date);
		 System.out.println(intervalPeriod.getDays());
		 long penalty= intervalPeriod.getDays();
		 if(penalty>15)
		 {
			 penalty=penalty-15;
		 }
		 else
		 {
			 penalty=0;
		 }
		 entity.setPenalty(penalty);
		return this.subservice.issueBook(entity);
	}
	
	

}
