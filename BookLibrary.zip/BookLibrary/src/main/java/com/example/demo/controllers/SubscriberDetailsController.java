package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.BookDetails;
import com.example.demo.model.Subscriber;
import com.example.demo.service.SubscriberDetailsService;

@RestController
public class SubscriberDetailsController {
	
	@Autowired
	private SubscriberDetailsService subservice;
	
	@GetMapping(value="/getSubscriber/{id}")
	//@Secured("ROLE_USER")
    public Subscriber showSubscriber(@PathVariable("id") long id)
	{
	return this.subservice.showDetails(id).get();
	}
	
	@PostMapping(value= "/issueBook" , produces="application/json", consumes="application/json")
	//@Secured("ROLE_ADMIN")
	public Subscriber sendSubscriberDetails(@RequestBody  Subscriber entity)
	{
		return this.subservice.issueBook(entity);
	}
	
	

}
