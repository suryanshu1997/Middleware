package com.example.demo.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Cars;
@Repository
public class RepositoryImpl implements MyRepository<Cars> {
	
	
	@Autowired
	private MongoTemplate template;

	@Override
	public Cars save(Cars t) {
		// TODO Auto-generated method stub
		return template.save(t);
	}

	@Override
	public List<Cars> findAll() {
		// TODO Auto-generated method stub
		return template.findAll(Cars.class);
	}
	
	public long remove(Cars t)
	{
		return template.remove(t).getDeletedCount();
	}
	
	
}
