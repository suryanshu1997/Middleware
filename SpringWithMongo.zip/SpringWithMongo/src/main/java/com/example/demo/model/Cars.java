package com.example.demo.model;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import lombok.NoArgsConstructor;
@Document(collection ="cars")
@Data
@NoArgsConstructor
public class Cars {
	
	
	private ObjectId id;
	private String brand;
	private List<String> model;
	private Owner owner;
	private Address address;
	@DBRef
	private Dealer dealer;

}
