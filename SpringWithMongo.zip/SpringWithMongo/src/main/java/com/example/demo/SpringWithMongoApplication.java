package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.example.demo.model.Cars;
import com.example.demo.model.Dealer;
import com.example.demo.repo.DealerRepo;
import com.example.demo.repo.MyRepository;

@SpringBootApplication
public class SpringWithMongoApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx=SpringApplication.run(SpringWithMongoApplication.class, args);
		
		MyRepository<Cars> repo=ctx.getBean("repositoryImpl",MyRepository.class);
		Cars car=ctx.getBean(Cars.class);
		Cars saved=repo.save(car);
		
		
		MyRepository<Dealer> rep2= ctx.getBean(DealerRepo.class);
		Dealer dealer = ctx.getBean(Dealer.class);
		Dealer saved2=rep2.save(dealer);
		
		car.setDealer(saved2);
		repo.save(car);
		System.out.println("One car with Details saved"+saved);
		ctx.close();
	}

}
