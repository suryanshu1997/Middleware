package com.example.demo.repos;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Catlog;
@Repository
public interface CatlogRepository extends CassandraRepository<Catlog, Integer> {

}
