package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import com.example.demo.model.Catlog;
import com.example.demo.service.CatlogService;

@SpringBootApplication
public class CassandraUsingRepoApplication {

	public static void main(String[] args) {
	 ConfigurableApplicationContext ctx=SpringApplication.run(CassandraUsingRepoApplication.class, args);
	 CatlogService service= ctx.getBean(CatlogService.class);
	 Catlog item=ctx.getBean(Catlog.class);
	 Catlog saved = service.add(item);
	 System.out.println("One item with details added"+saved);
	 ctx.close();
	
	}
	
	@Bean
	public Catlog catlog() {
		
		return new Catlog(905,"broadband","20 days",120);
	}

}
